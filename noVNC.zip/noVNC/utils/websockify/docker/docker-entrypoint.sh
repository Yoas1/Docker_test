#!/bin/sh
# vim: tabstop=4 shiftwidth=4 softtabstop=4

set -e

/opt/websockify/websockify-$VERSION/run "$@"
